# PLUTO panel（普鲁托面板）

> AstrBot 的会话上下文可视化面板：看得见 token 用量，也管得住上下文。

[![Version](https://img.shields.io/badge/version-1.10.2-2F5FD8)](CHANGELOG.md)
[![AstrBot](https://img.shields.io/badge/AstrBot-%E2%89%A54.11.4-4176E6)](https://github.com/AstrBotDevs/AstrBot)
[![Python](https://img.shields.io/badge/python-3.10%2B-3776AB?logo=python&logoColor=white)](https://www.python.org/)
[![License](https://img.shields.io/badge/license-MIT-3DA639)](LICENSE)

**PLUTO panel** 把 AstrBot 的「上下文占用」从看不见的数字变成一页看得懂的面板：每个会话用了多少 token、离上限还有多远、什么时候该压缩、压缩之后承接去哪了。在此基础上还集成联网搜索、抖音游客浏览监控、主动消息、推理完成通知与统一事件日志。

- 🎨 两套主题：**DeepSeek 暗夜吸黑** / **白色浅色**，一键切换、跨页记忆
- 📊 会话列表左右同屏，**置顶**分组与标记同步
- 🗜️ 压缩 / 承接全流程可视化，**先备份再动手**
- 🔍 内置 `web_search` 工具与检索日志，搜不搜由人设决定
- 🧾 统一事件日志：谁、何时、做了什么，全部落库

---

## 界面预览

| 上下文监控（暗夜吸黑） | 上下文监控（白色浅色） |
| --- | --- |
| ![context dark](assets/screenshots/context-dark.jpg) | ![context light](assets/screenshots/context-light.jpg) |

| 事件日志（暗夜吸黑） | 事件日志（白色浅色） |
| --- | --- |
| ![event log dark](assets/screenshots/event-log-dark.jpg) | ![event log light](assets/screenshots/event-log-light.jpg) |

| 会话置顶 | 联网搜索 |
| --- | --- |
| ![pin](assets/screenshots/pin-dark.jpg) | ![search](assets/screenshots/search-dark.jpg) |

---

## 功能清单

面板左侧共 12 个页面，每一页对应一类能力：

| 页面 | 能做什么 |
| --- | --- |
| **上下文监控** | 会话列表（左右两侧同屏）、token 进度条、模型窗口上限、置顶、统计弹窗、一键清空 |
| **联网搜索** | 搜索开关与提供商、`web_search` 工具说明、试搜、检索日志（成功/失败/耗时/条数） |
| **抖音浏览** | 游客浏览开关与参数、每轮记录（视频数、停留、风控）、手动触发 |
| **抖音风控调速** | 近 3 天加权分数、严格系数、降档/回升进度、命中记录 |
| **推理通知** | 整轮结束单条汇总、投递模式、Token/耗时/记忆状态、语音播报、通知日志 |
| **压缩承接** | 压缩当前会话、承接新会话、备份预览、压缩日志筛选 |
| **日记本** | 按会话写入的长期记忆、检索注入、单日上限 |
| **主动消息** | 情绪等级、静默时段、每日上限、反重复、发送记录 |
| **事件日志** | 概览、筛选查询、导出 JSON、导出数据库副本、清理过期记录 |
| **阈值与播报** | 预警百分比、高危线、自动播报开关与频率 |
| **行为 / 显示** | 各模块默认值、缩放、主题与外观 |

### 核心能力

- **上下文可视化**：读取 AstrBot 官方会话与 provider 统计，不估算；模型没有窗口上限时明确提示「未知」，不瞎猜。
- **压缩 / 承接**：把长会话压成一页摘要，或换新会话带着摘要与最近几轮继续；动手前把原始历史备份到 `carry_backups/`（每会话最多 20 份）。
- **置顶**：置顶列表写在 `settings.json` 的 `pinned` 字段，左右两侧读同一份数据，刷新与重载后仍在。
- **联网搜索**：内置 `web_search` 工具（DeepSeek / Tavily / 博查，任选其一），每次检索写本地日志；「要不要搜」由人设与工具描述共同决定。
- **抖音游客浏览**：Playwright 驱动的游客页浏览，只逛精选、不搜索、不登录，命中安全验证立即停止并进入冷却。
- **风控调速**：72 小时半衰期 24 小时的加权分数，触发验证即降档，90 分钟无新增后匀速回升，8 秒停留是硬底线。
- **推理通知**：只在整轮推理结束后发一条汇总，流式过程不刷屏；可选语音。
- **事件日志**：SQLite 主库 + JSONL 双写，30 天 / 20000 行保留上限，面板可直接维护与导出。

---

## 安装

### 方式一：插件市场（推荐）

1. 打开 AstrBot 后台 → **插件市场** → 搜索「PLUTO panel」或「Token 面板」；
2. 安装后到 **插件管理** 启用；
3. 进入 **扩展功能** → **PLUTO panel**。

### 方式二：压缩包

1. 下载 Release 里的 `astrbot_plugin_token_panel.zip`；
2. 后台 → 插件市场 → 右上角「安装插件」→ 选择该 zip；
3. 重载插件。

### 方式三：手动放置

```bash
cd AstrBot/data/plugins
git clone https://github.com/<your-name>/astrbot_plugin_token_panel.git
```

目录结构必须是 `data/plugins/astrbot_plugin_token_panel/`（外层文件夹名与插件 id 一致），否则面板路由不会注册。
放好后在后台点「重载」，日志出现 `[token_panel] 1.10.2 初始化完成` 即成功。

### 依赖

| 依赖 | 说明 |
| --- | --- |
| AstrBot | **≥ 4.11.4**（面板页与 `register_web_api` 所需） |
| Python | 3.10+（AstrBot 自带环境即可） |
| httpx | 联网搜索用，AstrBot 环境已内置 |
| Playwright（可选） | 仅「抖音游客浏览」需要：`pip install playwright && playwright install chromium` |
| 搜索 API Key（可选） | 用联网搜索时填写，只存在本地 `settings.json` |

不需要 Node、不需要数据库迁移，装完即可用。

---

## 首次使用

1. **打开面板**：后台 → 扩展功能 → PLUTO panel；
2. **看用量**：左侧「上下文监控」列出所有会话与当前占用，点会话可看详情；
3. **设阈值**：「阈值与播报」里设预警百分比（默认 80%，高危线固定 95%）；
4. **按需开启模块**：联网搜索、抖音浏览、主动消息、推理通知默认都是关闭的，用哪个开哪个。

---

## 主题说明

面板只保留两套主题，均为同一套设计令牌驱动，切换即生效、刷新后保持：

| 主题 | 画布 | 强调色 | 适合 |
| --- | --- | --- | --- |
| **暗夜吸黑**（dark） | `#151517` | `#4176E6` | 夜间、长时间盯屏 |
| **白色浅色**（light） | `#FFFFFF` | `#2F5FD8` | 白天、投屏演示 |

- 入口：左下角「显示」页 → 主题；选择会写入本地 `settings.json`，多个页面/iframe 共享。
- 字号 8 档、圆角 16、0.5px 发丝线、动效 80–240ms，全部走 CSS 变量（`--dsw-alias-*`），不写死颜色。
- 旧版本曾有一个 Claude 风格配色，**已在 v1.8.0 起从界面移除**；配置里的 `style` 字段仅为兼容老安装保留，新装默认 DeepSeek 蓝调。

---

## 指令速查

所有指令均需在 QQ 里 @机器人 或私聊发送 `/指令`（仅管理员可用的会标注）。

### 上下文与 Token

| 指令 | 说明 |
| --- | --- |
| `/token_ctx` | 查看当前会话 token 进度条 |
| `/token_ctxon` `/token_ctxoff` | 开关自动进度播报（管理员） |
| `/token_ctxset 80` | 修改预警阈值（管理员） |
| `/token_clearctx` | 清空当前会话上下文（二次确认，管理员） |
| `/ctx` | 查看上下文用量明细 |
| `/ctx_sessions` | 列出本会话最近的会话 |
| `/ctx_switch <前8位>` | 切换到指定会话（管理员） |

### 压缩与承接

| 指令 | 说明 |
| --- | --- |
| `/ctx_compress [保留轮数]` | 压缩当前会话（管理员） |
| `/ctx_continue [保留轮数]` | 压成摘要并换到新会话（管理员） |
| `/ctx_auto [on\|off]` | 查看或切换自动压缩（管理员） |
| `/ctx_diary` `/ctx_diary_clear` | 查看 / 清空会话日记（管理员可清空） |

### 抖音浏览

| 指令 | 说明 |
| --- | --- |
| `/dy_on` `/dy_off` | 开关游客浏览（管理员） |
| `/dy_test` | 立刻浏览一次（管理员） |
| `/dy_status` `/net_log` | 查看浏览状态 |
| `/dy_log` | 让模型用平时语气汇报浏览记录（管理员） |
| `/dy_set` | 设置浏览参数（管理员） |

### 通知、语音与主动消息

| 指令 | 说明 |
| --- | --- |
| `/notify_on` `/notify_off` `/notify_toggle` | 开关推理完成通知（管理员） |
| `/notify_status` | 查看通知配置 |
| `/notify_mode session\|admin\|both` | 投递模式（管理员） |
| `/notify_text` `/notify_errtext` | 自定义成功 / 失败文案（管理员） |
| `/tts_toggle` `/tts_private` `/tts_group` | 语音总开关 / 私聊 / 群聊（管理员） |
| `/tts_voice <音色ID>` `/tts_speed <0.5~2.0>` | 音色与语速（管理员） |
| `/proactive` `/proactive-status` `/proactive-reset` | 主动消息开关 / 状态 / 重置（管理员） |

---

## 数据与隐私

所有数据都在本机的插件数据目录，**不上传任何服务器**：

```
data/plugin_data/astrbot_plugin_token_panel/
├── settings.json            主题、置顶、各模块配置（含搜索 API Key 明文）
├── event_log.db / .jsonl    事件日志
├── websearch/search_log.db  检索日志
├── proactive.db             主动消息记录
├── notify_log.json          推理通知记录
├── carry_backups/           压缩前备份
└── compress_log.json        压缩日志
```

- 面板只读 AstrBot 官方会话库与 provider 统计，不改写聊天记录；
- 清空上下文使用官方 `update_conversation(token_usage=...)`，有二次确认；
- 压缩 / 承接先备份再执行，备份可回看；
- 从仓库上传角度：`settings.json`、`*.db`、`*.jsonl`、`carry_backups/` 全部在 `.gitignore` 里，不会被提交。

---

## 常见问题

**Q：面板打不开或白屏？**
看 AstrBot 日志里有没有 `token_panel` 报错；确认插件目录名是 `astrbot_plugin_token_panel`；在插件管理里点「重载」，然后 Ctrl+F5 强刷。

**Q：token 数是估算的吗？**
不是。列表与统计读官方 `conversations.token_usage` 与 `provider_stats`；只有压缩/承接页里的「估算」是本地口径（中文 ×0.6、其它 ×0.3、每条 +4）。

**Q：为什么有的会话显示「未设置窗口上限」？**
该模型元数据里没有 context 上限时，面板不会猜，直接显示未知。可在「显示」页填手动兜底，或 `/token_ctxset`。

**Q：压缩会不会丢内容？**
压缩前把整段历史备份到 `carry_backups/`（每会话最近 20 份），日志里能看到备份文件名并一键预览。

**Q：承接和压缩的区别？**
压缩在同一会话内替换旧对话；承接新建会话并带上摘要与最近几轮，旧会话保留可切回。

**Q：置顶刷新后会丢吗？**
不会，置顶写在 `settings.json` 的 `pinned` 字段，左右两侧共用。

**Q：抖音浏览会被风控吗？**
只走游客页、不登录、随机停留、每日次数与时长有上限；命中安全验证立即停止并冷却 30 分钟，期间不自动重试。

**Q：搜索 Key 会被上传吗？**
不会，只存本地 `settings.json`，面板显示时做掩码。

**Q：升级会覆盖配置吗？**
不会。升级只替换代码文件，`plugin_data/` 里的配置与日志保留。

**Q：事件日志只记录面板操作吗？**
是。只记录面板与插件内动作，不记录聊天内容与每次模型回复，避免日志膨胀与隐私风险。

---

## 目录结构

```
astrbot_plugin_token_panel/
├── main.py                 插件入口：面板路由、会话统计、压缩承接、置顶、指令
├── eventlog.py             事件日志（SQLite + JSONL）
├── websearch.py            联网搜索模块（工具 + 日志）
├── proactive.py            主动消息引擎
├── notify.py               推理完成通知
├── risk_tuning.py          抖音风控调速（纯算法，无 IO）
├── tts_module.py           语音合成（复用原生 TTSProvider）
├── views/dashboard/        面板页面（单页应用：12 个视图）
├── worker/douyin_worker.py 抖音游客浏览 worker（Playwright）
├── assets/                 图标、横幅、截图
├── docs/                   详细文档、历史更新说明
├── tools/pack.ps1          打包脚本
├── _conf_schema.json       插件配置项声明
├── metadata.yaml           插件市场元数据
└── plugin.json             插件清单
```

---

## 更新日志

完整版本记录见 [CHANGELOG.md](CHANGELOG.md)。近期重点：

- **v1.10.2** 统一事件日志（SQLite + JSONL、面板维护页）
- **v1.10.1 / v1.9.1** 会话置顶：左右同步与视觉统一
- **v1.10.0** 「何时该搜」写进人设，工具说明与指令一致
- **v1.9.0** 联网搜索模块内聚进面板
- **v1.8.0** 视觉系统重做：三栏布局、双主题令牌化

---

## 参与贡献

- 发现 bug 或有建议：开 Issue（附版本、日志片段、复现步骤）；
- 提交代码：fork → 分支 → PR，保持一个 PR 只做一件事；
- 不接受把密钥、QQ 号、个人路径写进代码的改动。

## 开源协议

[MIT](LICENSE) © Charon

## 免责声明

本插件为个人使用与学习用途，抖音浏览、联网搜索等功能请遵守平台条款与当地法律法规；因使用本插件产生的账号风险由使用者自行承担。